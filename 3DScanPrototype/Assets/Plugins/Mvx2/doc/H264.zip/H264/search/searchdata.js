var indexSectionsWithContent =
{
  0: "cdmr",
  1: "cdmr"
};

var indexSectionNames =
{
  0: "all",
  1: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Pages"
};

