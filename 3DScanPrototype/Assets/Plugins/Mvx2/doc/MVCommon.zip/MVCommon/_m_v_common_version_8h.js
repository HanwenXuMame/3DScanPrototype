var _m_v_common_version_8h =
[
    [ "MVCOMMON_VERSION_MAJOR", "_m_v_common_version_8h.html#a2050487c191a59d4d025eb03ec0bb469", null ],
    [ "MVCOMMON_VERSION_MINOR", "_m_v_common_version_8h.html#af6f1d149d370d29e31dc99e8315e8dfa", null ],
    [ "MVCOMMON_VERSION_PATCH", "_m_v_common_version_8h.html#a22616ec46e27507170628a857e798860", null ],
    [ "MVCOMMON_VERSION", "_m_v_common_version_8h.html#a89fee79a1019b88b06959d8a687124ea", null ]
];