var searchData=
[
  ['patch_520',['patch',['../struct_m_v_common_1_1_version_info.html#a260b389f1deca8ef25ac0d4c26dc2e42',1,'MVCommon::VersionInfo']]]
];
