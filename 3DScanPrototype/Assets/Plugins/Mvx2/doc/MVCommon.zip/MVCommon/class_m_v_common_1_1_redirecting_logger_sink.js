var class_m_v_common_1_1_redirecting_logger_sink =
[
    [ "RedirectingLoggerSink", "class_m_v_common_1_1_redirecting_logger_sink.html#a6127fcb3f06129a0e7b9d41cf1dd425c", null ],
    [ "~RedirectingLoggerSink", "class_m_v_common_1_1_redirecting_logger_sink.html#afc4e5221a747133eddef0169dd940451", null ],
    [ "HandleLogEntry", "class_m_v_common_1_1_redirecting_logger_sink.html#ac79f103fe423c2664d6397ac9796134b", null ]
];