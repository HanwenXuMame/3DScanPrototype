var dir_d616597e28a23af1b5be84e112065d1b =
[
    [ "AndroidSystemLoggerSink.h", "_android_system_logger_sink_8h_source.html", null ],
    [ "AppleSystemLoggerSink.h", "_apple_system_logger_sink_8h_source.html", null ],
    [ "FileLoggerSink.h", "_file_logger_sink_8h_source.html", null ],
    [ "RedirectingLoggerSink.h", "_redirecting_logger_sink_8h_source.html", null ],
    [ "StdOutLoggerSink.h", "_std_out_logger_sink_8h_source.html", null ]
];