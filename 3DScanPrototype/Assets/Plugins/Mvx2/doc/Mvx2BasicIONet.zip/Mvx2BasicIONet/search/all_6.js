var searchData=
[
  ['issingleframe_25',['IsSingleFrame',['../class_mvx2_basic_i_o_1_1_mvx2_file_basic_data_info.html#a82e299e32c52982f2bdf3339bbcdbb9d',1,'Mvx2BasicIO::Mvx2FileBasicDataInfo']]],
  ['isvalid_26',['IsValid',['../class_mvx2_basic_i_o_1_1_mvx2_file_basic_data_info.html#af262ec5011c4e3f24b23f1df2af1e12a',1,'Mvx2BasicIO::Mvx2FileBasicDataInfo']]]
];
