var indexSectionsWithContent =
{
  0: "cdefghimnprs",
  1: "mn",
  2: "m",
  3: "cdeghimnprs",
  4: "f",
  5: "f",
  6: "f",
  7: "mr"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Pages"
};

