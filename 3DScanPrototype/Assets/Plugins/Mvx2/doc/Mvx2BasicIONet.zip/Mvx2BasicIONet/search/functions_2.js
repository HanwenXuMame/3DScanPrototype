var searchData=
[
  ['enablerecording_63',['EnableRecording',['../class_mvx2_basic_i_o_1_1_mvx2_file_async_writer_graph_node.html#a2377bfa509286416141098f567d5bcd2',1,'Mvx2BasicIO.Mvx2FileAsyncWriterGraphNode.EnableRecording()'],['../class_mvx2_basic_i_o_1_1_mvx2_file_writer_graph_node.html#ab03361f63feb83e0f1899179c02314b8',1,'Mvx2BasicIO.Mvx2FileWriterGraphNode.EnableRecording()']]],
  ['enabletransmission_64',['EnableTransmission',['../class_mvx2_basic_i_o_1_1_network_transmitter_graph_node.html#a0d6b3195193389d5f675c4781ed6d60e',1,'Mvx2BasicIO::NetworkTransmitterGraphNode']]]
];
