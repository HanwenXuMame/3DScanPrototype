var namespaces_dup =
[
    [ "Mvx2BasicIO", "namespace_mvx2_basic_i_o.html", null ]
];