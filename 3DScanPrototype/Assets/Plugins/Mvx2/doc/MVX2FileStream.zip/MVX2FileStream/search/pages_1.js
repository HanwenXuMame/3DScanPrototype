var searchData=
[
  ['reading_20filters_10',['Reading filters',['../reader_filters.html',1,'']]],
  ['release_20notes_11',['Release Notes',['../release_notes.html',1,'']]]
];
