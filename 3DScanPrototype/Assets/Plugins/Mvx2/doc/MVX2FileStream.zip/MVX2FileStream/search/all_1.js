var searchData=
[
  ['reading_20filters_2',['Reading filters',['../reader_filters.html',1,'']]],
  ['release_20notes_3',['Release Notes',['../release_notes.html',1,'']]]
];
