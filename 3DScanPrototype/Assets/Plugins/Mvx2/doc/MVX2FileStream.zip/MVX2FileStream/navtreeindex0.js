var NAVTREEINDEX0 =
{
"_mutate_remote_m_v_x2_file_async_reader.html":[2,3],
"_source_mvx2_byte_array_reader.html":[3],
"_source_remote_m_v_x2_file_async_realtime_reader.html":[2,1],
"_source_remote_m_v_x2_file_mutate_async_reader_backend.html":[2,2],
"_source_remote_m_v_x2_file_sync_reader.html":[2,0],
"index.html":[0],
"index.html":[],
"pages.html":[],
"reader_filters.html":[2],
"release_notes.html":[1]
};
