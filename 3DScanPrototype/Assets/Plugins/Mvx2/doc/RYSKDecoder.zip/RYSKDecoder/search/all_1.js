var searchData=
[
  ['bsd_20license_1',['BSD license',['../bsd_license.html',1,'nanoflann_notes']]]
];
