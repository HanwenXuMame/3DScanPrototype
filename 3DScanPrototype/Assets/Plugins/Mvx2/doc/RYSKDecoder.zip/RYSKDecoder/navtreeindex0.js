var NAVTREEINDEX0 =
{
"_data_type_r_y_s_k_data.html":[1,0],
"_mutate_r_y_s_k_decoder.html":[3,1],
"_mutate_r_y_s_k_encoder.html":[3,0],
"_target_r_y_s_k_writer.html":[3,2],
"apache_v2_license.html":[2,0],
"bsd_license.html":[4,0],
"data_layers.html":[1],
"draco_notes.html":[2],
"filters.html":[3],
"index.html":[0],
"index.html":[],
"nanoflann_notes.html":[4],
"pages.html":[],
"release_notes.html":[5]
};
