var class_mvx2_a_p_i_1_1_utils =
[
    [ "GetAppExeDirectory", "class_mvx2_a_p_i_1_1_utils.html#aeca5e0eda548221b62768abcbf23d660", null ],
    [ "GetAppExeFilePath", "class_mvx2_a_p_i_1_1_utils.html#a4ca2063d5a1540b7e5eddd3efc48c77a", null ],
    [ "MVXGuidAliasDatabase", "class_mvx2_a_p_i_1_1_utils.html#a6ee91f815baa348a369c3da51da1018e", null ],
    [ "MVXLoggerInstance", "class_mvx2_a_p_i_1_1_utils.html#af0a81b263a3f560959eef62e0d3617ff", null ]
];