var class_mvx2_a_p_i_1_1_delegated_frame_listener =
[
    [ "DelegatedFrameListener", "class_mvx2_a_p_i_1_1_delegated_frame_listener.html#a0489337e53531f56a03dcc3e775afbbe", null ],
    [ "OnFrameProcessed", "class_mvx2_a_p_i_1_1_delegated_frame_listener.html#aec2232ace4d6d80f4a9ed466c3b84325", null ],
    [ "OnFrameProcessedDelegate", "class_mvx2_a_p_i_1_1_delegated_frame_listener.html#aa9c4253bd9bb4a789bcc14ef440dd97a", null ]
];