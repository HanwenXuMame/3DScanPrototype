var class_mvx2_a_p_i_1_1_frame =
[
    [ "Frame", "class_mvx2_a_p_i_1_1_frame.html#a7910ba034b0f1463c3b7a6faa3aafc21", null ],
    [ "ActivateStreamWithIndex", "class_mvx2_a_p_i_1_1_frame.html#aa751a4a83d51e6b5f2bb3ab96ed20dd2", null ],
    [ "CreateDataProfilesEnumerator", "class_mvx2_a_p_i_1_1_frame.html#aa1a82fd5b4a742d0f2efdcd45866a860", null ],
    [ "DestroyNativeObject", "class_mvx2_a_p_i_1_1_frame.html#a4e3bf8ad3788661f151012f591fe3a42", null ],
    [ "GetActiveStreamIndex", "class_mvx2_a_p_i_1_1_frame.html#a0ed2dd215c7097f4eb0e763faffac2e1", null ],
    [ "GetNumStreams", "class_mvx2_a_p_i_1_1_frame.html#a1c6683e99a93b8a5cb308a1619d846f5", null ],
    [ "GetStreamAtomNr", "class_mvx2_a_p_i_1_1_frame.html#aa774a83409bc438963ee381f9dd979f9", null ],
    [ "GetStreamAtomTimestamp", "class_mvx2_a_p_i_1_1_frame.html#a2d78fec5c63a580695bed1d5c54657c9", null ],
    [ "GetStreamId", "class_mvx2_a_p_i_1_1_frame.html#aeaf0697f527a4f9ec1a875bdbb834d0a", null ],
    [ "StreamContainsDataLayer", "class_mvx2_a_p_i_1_1_frame.html#add065f5236e9ff499b647c3ab8fee274", null ],
    [ "StreamContainsDataLayer", "class_mvx2_a_p_i_1_1_frame.html#a3ad869c1f06f3ec77daf1dd90a7f4d79", null ],
    [ "DataProfilesBeginIterator", "class_mvx2_a_p_i_1_1_frame.html#aae6875b1712daee46c868730edb5a63f", null ],
    [ "DataProfilesEndIterator", "class_mvx2_a_p_i_1_1_frame.html#a8d9512af46eb1165b28c854fd4d26351", null ],
    [ "nativeFrameObject", "class_mvx2_a_p_i_1_1_frame.html#a56f9e1ad8856dfcbfc9fbe6f643c3755", null ]
];