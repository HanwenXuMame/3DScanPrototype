var namespaces_dup =
[
    [ "Mvx2API", "namespace_mvx2_a_p_i.html", "namespace_mvx2_a_p_i" ]
];