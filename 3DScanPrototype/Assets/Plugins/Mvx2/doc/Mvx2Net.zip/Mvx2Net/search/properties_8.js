var searchData=
[
  ['purposeguid_495',['purposeGuid',['../class_mvx2_a_p_i_1_1_data_profile.html#ad8a3bda6a7bdaee43d5b8c489047890f',1,'Mvx2API::DataProfile']]]
];
