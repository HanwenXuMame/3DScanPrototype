var searchData=
[
  ['r_439',['r',['../struct_mvx2_a_p_i_1_1_col.html#a63cc4bbceddec675ede2659d28c8831e',1,'Mvx2API::Col']]]
];
