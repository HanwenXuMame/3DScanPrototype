var searchData=
[
  ['col_243',['Col',['../struct_mvx2_a_p_i_1_1_col.html',1,'Mvx2API']]]
];
