var hierarchy =
[
    [ "Mvx2API.BasicDataLayersGuids", "class_mvx2_a_p_i_1_1_basic_data_layers_guids.html", null ],
    [ "Mvx2API.Col", "struct_mvx2_a_p_i_1_1_col.html", null ],
    [ "Mvx2API.FrameAudioExtractor", "class_mvx2_a_p_i_1_1_frame_audio_extractor.html", null ],
    [ "Mvx2API.FrameMeshExtractor", "class_mvx2_a_p_i_1_1_frame_mesh_extractor.html", null ],
    [ "Mvx2API.FrameMiscDataExtractor", "class_mvx2_a_p_i_1_1_frame_misc_data_extractor.html", null ],
    [ "Mvx2API.FrameTextureExtractor", "class_mvx2_a_p_i_1_1_frame_texture_extractor.html", null ],
    [ "IEnumerator", null, [
      [ "Mvx2API.DataProfileEnumerator", "class_mvx2_a_p_i_1_1_data_profile_enumerator.html", null ],
      [ "Mvx2API.FilterParameterNameEnumerator", "class_mvx2_a_p_i_1_1_filter_parameter_name_enumerator.html", null ]
    ] ],
    [ "IEquatable", null, [
      [ "Mvx2API.DataProfile", "class_mvx2_a_p_i_1_1_data_profile.html", null ]
    ] ],
    [ "NativeObjectHolder", null, [
      [ "Mvx2API.DataProfile", "class_mvx2_a_p_i_1_1_data_profile.html", null ],
      [ "Mvx2API.Frame", "class_mvx2_a_p_i_1_1_frame.html", null ],
      [ "Mvx2API.FrameListener", "class_mvx2_a_p_i_1_1_frame_listener.html", [
        [ "Mvx2API.DelegatedFrameListener", "class_mvx2_a_p_i_1_1_delegated_frame_listener.html", null ]
      ] ],
      [ "Mvx2API.Graph", "class_mvx2_a_p_i_1_1_graph.html", null ],
      [ "Mvx2API.GraphBuilder", "class_mvx2_a_p_i_1_1_graph_builder.html", [
        [ "Mvx2API.ManualGraphBuilder", "class_mvx2_a_p_i_1_1_manual_graph_builder.html", null ]
      ] ],
      [ "Mvx2API.GraphNode", "class_mvx2_a_p_i_1_1_graph_node.html", [
        [ "Mvx2API.AsyncFrameAccessGraphNode", "class_mvx2_a_p_i_1_1_async_frame_access_graph_node.html", null ],
        [ "Mvx2API.AutoCompressorGraphNode", "class_mvx2_a_p_i_1_1_auto_compressor_graph_node.html", null ],
        [ "Mvx2API.AutoDecompressorGraphNode", "class_mvx2_a_p_i_1_1_auto_decompressor_graph_node.html", null ],
        [ "Mvx2API.BlockGraphNode", "class_mvx2_a_p_i_1_1_block_graph_node.html", [
          [ "Mvx2API.BlockFPSGraphNode", "class_mvx2_a_p_i_1_1_block_f_p_s_graph_node.html", null ],
          [ "Mvx2API.BlockManualGraphNode", "class_mvx2_a_p_i_1_1_block_manual_graph_node.html", null ]
        ] ],
        [ "Mvx2API.Experimental.RendererGraphNode", "class_mvx2_a_p_i_1_1_experimental_1_1_renderer_graph_node.html", null ],
        [ "Mvx2API.FrameAccessGraphNode", "class_mvx2_a_p_i_1_1_frame_access_graph_node.html", null ],
        [ "Mvx2API.InjectFileDataGraphNode", "class_mvx2_a_p_i_1_1_inject_file_data_graph_node.html", null ],
        [ "Mvx2API.InjectMemoryDataGraphNode", "class_mvx2_a_p_i_1_1_inject_memory_data_graph_node.html", null ],
        [ "Mvx2API.ManualLiveFrameSourceGraphNode", "class_mvx2_a_p_i_1_1_manual_live_frame_source_graph_node.html", null ],
        [ "Mvx2API.ManualOfflineFrameSourceGraphNode", "class_mvx2_a_p_i_1_1_manual_offline_frame_source_graph_node.html", null ],
        [ "Mvx2API.SingleFilterGraphNode", "class_mvx2_a_p_i_1_1_single_filter_graph_node.html", null ]
      ] ],
      [ "Mvx2API.GraphRunner", "class_mvx2_a_p_i_1_1_graph_runner.html", [
        [ "Mvx2API.AutoSequentialGraphRunner", "class_mvx2_a_p_i_1_1_auto_sequential_graph_runner.html", null ],
        [ "Mvx2API.ManualSequentialGraphRunner", "class_mvx2_a_p_i_1_1_manual_sequential_graph_runner.html", null ],
        [ "Mvx2API.RandomAccessGraphRunner", "class_mvx2_a_p_i_1_1_random_access_graph_runner.html", null ]
      ] ],
      [ "Mvx2API.InputEvent", "class_mvx2_a_p_i_1_1_input_event.html", [
        [ "Mvx2API.KeyDownEvent", "class_mvx2_a_p_i_1_1_key_down_event.html", null ],
        [ "Mvx2API.KeyUpEvent", "class_mvx2_a_p_i_1_1_key_up_event.html", null ],
        [ "Mvx2API.MouseDoubleClickEvent", "class_mvx2_a_p_i_1_1_mouse_double_click_event.html", null ],
        [ "Mvx2API.MouseDownEvent", "class_mvx2_a_p_i_1_1_mouse_down_event.html", null ],
        [ "Mvx2API.MouseMoveEvent", "class_mvx2_a_p_i_1_1_mouse_move_event.html", null ],
        [ "Mvx2API.MouseUpEvent", "class_mvx2_a_p_i_1_1_mouse_up_event.html", null ],
        [ "Mvx2API.MouseWheelEvent", "class_mvx2_a_p_i_1_1_mouse_wheel_event.html", null ]
      ] ],
      [ "Mvx2API.MeshData", "class_mvx2_a_p_i_1_1_mesh_data.html", null ],
      [ "Mvx2API.MeshSplitter", "class_mvx2_a_p_i_1_1_mesh_splitter.html", null ],
      [ "Mvx2API.ParameterValueChangedListener", "class_mvx2_a_p_i_1_1_parameter_value_changed_listener.html", [
        [ "Mvx2API.DelegatedParameterValueChangedListener", "class_mvx2_a_p_i_1_1_delegated_parameter_value_changed_listener.html", null ]
      ] ],
      [ "Mvx2API.SourceInfo", "class_mvx2_a_p_i_1_1_source_info.html", null ]
    ] ],
    [ "Mvx2API.PluginsLoader", "class_mvx2_a_p_i_1_1_plugins_loader.html", null ],
    [ "Mvx2API.Utils", "class_mvx2_a_p_i_1_1_utils.html", null ],
    [ "Mvx2API.Vec2", "struct_mvx2_a_p_i_1_1_vec2.html", null ],
    [ "Mvx2API.Vec3", "struct_mvx2_a_p_i_1_1_vec3.html", null ]
];