var annotated_dup =
[
    [ "MVZMQNetwork", null, [
      [ "Receiver", "class_m_v_z_m_q_network_1_1_receiver.html", "class_m_v_z_m_q_network_1_1_receiver" ],
      [ "Transmitter", "class_m_v_z_m_q_network_1_1_transmitter.html", "class_m_v_z_m_q_network_1_1_transmitter" ]
    ] ]
];