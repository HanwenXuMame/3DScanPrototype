var _filter_category_8h =
[
    [ "FilterCategory", "_filter_category_8h.html#a2b456d074ff032f6256bccd23270d9c0", [
      [ "FC_UNKNOWN", "_filter_category_8h.html#a2b456d074ff032f6256bccd23270d9c0a14c132230c6cfdf727b348dff6622de7", null ],
      [ "FC_SOURCE", "_filter_category_8h.html#a2b456d074ff032f6256bccd23270d9c0a604b53ae704db6e86e765045fd0b5259", null ],
      [ "FC_TRANSFORM", "_filter_category_8h.html#a2b456d074ff032f6256bccd23270d9c0a6c94e3571346daaabe04f321ec12c2dc", null ],
      [ "FC_TRANSFORM_TEXTURECONVERSION", "_filter_category_8h.html#a2b456d074ff032f6256bccd23270d9c0af7f4c4ba151a128c526f7ed22e4828a5", null ],
      [ "FC_TRANSFORM_TEXTURECOLOR", "_filter_category_8h.html#a2b456d074ff032f6256bccd23270d9c0a19dbfeaa9b82c7f27e5a40550f299826", null ],
      [ "FC_TARGET", "_filter_category_8h.html#a2b456d074ff032f6256bccd23270d9c0a544092a8f85d4c6621f7c1000cc8cb0d", null ],
      [ "FC_RENDERER", "_filter_category_8h.html#a2b456d074ff032f6256bccd23270d9c0a8ddbd9f1cd44e1573ef65e86786cccdd", null ],
      [ "FC_TRANSFORM_COMPRESSOR", "_filter_category_8h.html#a2b456d074ff032f6256bccd23270d9c0a61c020269ebfd938af651c8a5a2afe4a", null ],
      [ "FC_TRANSFORM_DECOMPRESSOR", "_filter_category_8h.html#a2b456d074ff032f6256bccd23270d9c0a624d4044ea03ebfc16cbf897e98bd9f7", null ]
    ] ],
    [ "DetermineFilterCategory", "_filter_category_8h.html#a26d5b7513ca89b81b1b35a17fc161ab4", null ],
    [ "GetFilterCategoryName", "_filter_category_8h.html#a92edc5542a0cb7d6c7a894f7460b2622", null ]
];