var _basic_data_layers_guids_8h =
[
    [ "ASTC_TEXTURE_DATA_LAYER", "_basic_data_layers_guids_8h.html#ac4a77a3d53df3a7ee0473f5dffdc9d15", null ],
    [ "AUDIO_DATA_LAYER", "_basic_data_layers_guids_8h.html#a3ae23bd68d599c0490ce4f650d66a859", null ],
    [ "BYTEARRAY_DATA_LAYER", "_basic_data_layers_guids_8h.html#ac0ef4db787d4e4364bb5b625bce52f6a", null ],
    [ "CAMERA_PARAMS_DATA_LAYER", "_basic_data_layers_guids_8h.html#a355ec13a97b789ea8765bd34a320a45b", null ],
    [ "DEPTHMAP_TEXTURE_DATA_LAYER", "_basic_data_layers_guids_8h.html#a8da96aee7def080121717620003c7380", null ],
    [ "DXT1_TEXTURE_DATA_LAYER", "_basic_data_layers_guids_8h.html#a8f51eaa348770e8ed9f038284e3dc186", null ],
    [ "DXT5YCOCG_TEXTURE_DATA_LAYER", "_basic_data_layers_guids_8h.html#aa3c9f85ad139d40a35dfec3e824a3a42", null ],
    [ "ETC2_TEXTURE_DATA_LAYER", "_basic_data_layers_guids_8h.html#ae2af8e93f1fc6a96350c0be46e0f18c1", null ],
    [ "IR_TEXTURE_DATA_LAYER", "_basic_data_layers_guids_8h.html#a74a41a24fbabae9ddfc8632eab1c0bdd", null ],
    [ "NV12_TEXTURE_DATA_LAYER", "_basic_data_layers_guids_8h.html#a3f3a9d787c75856fcde90394e7ca4ad7", null ],
    [ "NV21_TEXTURE_DATA_LAYER", "_basic_data_layers_guids_8h.html#a8db67c9542a872d17302220001331d6e", null ],
    [ "NVX_TEXTURE_DATA_LAYER", "_basic_data_layers_guids_8h.html#a5705d53258fa6c3b0694f95f71d4f879", null ],
    [ "RGB_TEXTURE_DATA_LAYER", "_basic_data_layers_guids_8h.html#a79dccd4a8bc2eb34434f7d04c36376fa", null ],
    [ "SEGMENT_INFO_DATA_LAYER", "_basic_data_layers_guids_8h.html#a68bb57e244f259ccb17d624c34e5b8f3", null ],
    [ "TRANSFORM_DATA_LAYER", "_basic_data_layers_guids_8h.html#a27a77793dc02a426abc603d65f5c2930", null ],
    [ "VERTEX_COLORS_DATA_LAYER", "_basic_data_layers_guids_8h.html#a2733637977ea1f720ca9e3ab85f2108b", null ],
    [ "VERTEX_INDICES_DATA_LAYER", "_basic_data_layers_guids_8h.html#a35f04630def737decd8f1dd5324cd05a", null ],
    [ "VERTEX_NORMALS_DATA_LAYER", "_basic_data_layers_guids_8h.html#a0495e91a56fa1276b2f18a78605a3428", null ],
    [ "VERTEX_POSITIONS_DATA_LAYER", "_basic_data_layers_guids_8h.html#a12f2df072f55c57f00ee0681305c9649", null ],
    [ "VERTEX_UVS_DATA_LAYER", "_basic_data_layers_guids_8h.html#ad131b13385ae29b60a401a5c840138be", null ]
];