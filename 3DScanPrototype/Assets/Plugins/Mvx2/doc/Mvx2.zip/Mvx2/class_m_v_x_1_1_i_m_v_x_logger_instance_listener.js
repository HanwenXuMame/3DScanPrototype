var class_m_v_x_1_1_i_m_v_x_logger_instance_listener =
[
    [ "~IMVXLoggerInstanceListener", "class_m_v_x_1_1_i_m_v_x_logger_instance_listener.html#a44352bed327d329c10bb3b49086c7d7d", null ],
    [ "OnMVXLoggerInstanceChanged", "class_m_v_x_1_1_i_m_v_x_logger_instance_listener.html#a47bc53d2aaa76442907037c92d7016e2", null ]
];