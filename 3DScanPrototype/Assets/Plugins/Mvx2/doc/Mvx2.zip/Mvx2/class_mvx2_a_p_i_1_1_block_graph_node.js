var class_mvx2_a_p_i_1_1_block_graph_node =
[
    [ "FullBehaviour", "class_mvx2_a_p_i_1_1_block_graph_node.html#af56e4560a78f96cbe9fcc585d0bb100e", [
      [ "FB_DROP_FRAMES", "class_mvx2_a_p_i_1_1_block_graph_node.html#af56e4560a78f96cbe9fcc585d0bb100ea46739a55d2e8f2b5b6ed98ee7a99db62", null ],
      [ "FB_BLOCK_FRAMES", "class_mvx2_a_p_i_1_1_block_graph_node.html#af56e4560a78f96cbe9fcc585d0bb100eaafaa3152cd103405a52b80824f76e647", null ]
    ] ],
    [ "GetDroppedFramesCount", "class_mvx2_a_p_i_1_1_block_graph_node.html#aeef025e25091987b976360cec07f7909", null ],
    [ "ResetDroppedFramesCounter", "class_mvx2_a_p_i_1_1_block_graph_node.html#adbd3d5f2e3bed7b38e7ec8bc36438064", null ],
    [ "SetFullBehaviour", "class_mvx2_a_p_i_1_1_block_graph_node.html#a0996cde263ad4af87641dc392be88d06", null ]
];