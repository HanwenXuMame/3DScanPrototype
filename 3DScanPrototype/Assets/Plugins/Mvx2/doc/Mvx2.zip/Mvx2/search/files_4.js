var searchData=
[
  ['logger_2eh_496',['Logger.h',['../_logger_8h.html',1,'']]]
];
