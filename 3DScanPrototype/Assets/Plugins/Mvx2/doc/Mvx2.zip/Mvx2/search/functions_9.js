var searchData=
[
  ['keydownevent_629',['KeyDownEvent',['../struct_mvx2_a_p_i_1_1_key_down_event.html#a7db0bfa95a4d8165cece3dbd93df895b',1,'Mvx2API::KeyDownEvent::KeyDownEvent(int32_t key)'],['../struct_mvx2_a_p_i_1_1_key_down_event.html#af10d1986725343716dbf109f0d2a66ae',1,'Mvx2API::KeyDownEvent::KeyDownEvent(KeyDownEvent const &amp;other)'],['../struct_mvx2_a_p_i_1_1_key_down_event.html#ad5633ec6f7b10ae49f9da96b1d189359',1,'Mvx2API::KeyDownEvent::KeyDownEvent(KeyDownEvent &amp;&amp;other)']]],
  ['keyupevent_630',['KeyUpEvent',['../struct_mvx2_a_p_i_1_1_key_up_event.html#a272da1a7b32f6c1e7320beb42e9e2ad2',1,'Mvx2API::KeyUpEvent::KeyUpEvent(int32_t key)'],['../struct_mvx2_a_p_i_1_1_key_up_event.html#ade5ec513cbd350da1e87c4e4b7a599b7',1,'Mvx2API::KeyUpEvent::KeyUpEvent(KeyUpEvent const &amp;other)'],['../struct_mvx2_a_p_i_1_1_key_up_event.html#a58da8d4b0e9ef9a2bfaff24cd91919b4',1,'Mvx2API::KeyUpEvent::KeyUpEvent(KeyUpEvent &amp;&amp;other)']]]
];
