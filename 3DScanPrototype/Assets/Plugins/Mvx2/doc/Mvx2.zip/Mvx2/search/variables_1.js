var searchData=
[
  ['b_770',['b',['../struct_mvx2_a_p_i_1_1_col_r_g_b_a_data.html#a6608b7c809c631a19d558404e7e50d20',1,'Mvx2API::ColRGBAData']]]
];
