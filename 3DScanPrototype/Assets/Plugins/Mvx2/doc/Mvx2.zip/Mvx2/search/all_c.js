var searchData=
[
  ['nicifydatalayerclassname_224',['NicifyDataLayerClassName',['../class_m_v_x_1_1_data_layer_class_info.html#ab92b772c33cfd2826766815cff858ee9',1,'MVX::DataLayerClassInfo']]],
  ['nicifyfilterclassname_225',['NicifyFilterClassName',['../class_m_v_x_1_1_filter_class_info.html#a294a10571500ff6b5ff8784232439ce7',1,'MVX::FilterClassInfo']]],
  ['nv12_5ftexture_5fdata_5flayer_226',['NV12_TEXTURE_DATA_LAYER',['../_basic_data_layers_guids_8h.html#a3f3a9d787c75856fcde90394e7ca4ad7',1,'Mvx2API::BasicDataLayersGuids']]],
  ['nv21_5ftexture_5fdata_5flayer_227',['NV21_TEXTURE_DATA_LAYER',['../_basic_data_layers_guids_8h.html#a8db67c9542a872d17302220001331d6e',1,'Mvx2API::BasicDataLayersGuids']]],
  ['nvx_5ftexture_5fdata_5flayer_228',['NVX_TEXTURE_DATA_LAYER',['../_basic_data_layers_guids_8h.html#a5705d53258fa6c3b0694f95f71d4f879',1,'Mvx2API::BasicDataLayersGuids']]]
];
