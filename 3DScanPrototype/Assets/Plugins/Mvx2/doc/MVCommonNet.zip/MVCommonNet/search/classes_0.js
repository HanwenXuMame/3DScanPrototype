var searchData=
[
  ['androidsystemloggersink_200',['AndroidSystemLoggerSink',['../class_m_v_common_1_1_android_system_logger_sink.html',1,'MVCommon']]],
  ['applesystemloggersink_201',['AppleSystemLoggerSink',['../class_m_v_common_1_1_apple_system_logger_sink.html',1,'MVCommon']]]
];
