var searchData=
[
  ['green_389',['green',['../class_m_v_common_1_1_color.html#ae97465dd6993178c332eca08a6bafb4e',1,'MVCommon::Color']]],
  ['greenbyte_390',['greenByte',['../class_m_v_common_1_1_color.html#ab3c3e7d198d444e58e8fbf2ebae542b1',1,'MVCommon::Color']]]
];
