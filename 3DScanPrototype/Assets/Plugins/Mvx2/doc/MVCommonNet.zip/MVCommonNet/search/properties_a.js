var searchData=
[
  ['patch_414',['patch',['../class_m_v_common_1_1_version_info.html#a51296a0b2e4f77a64991103cd3380a6a',1,'MVCommon::VersionInfo']]]
];
