var class_mono_p_invoke_callback_attribute =
[
    [ "MonoPInvokeCallbackAttribute", "class_mono_p_invoke_callback_attribute.html#a28c46b180373d122ddb5df07804d76d6", null ]
];