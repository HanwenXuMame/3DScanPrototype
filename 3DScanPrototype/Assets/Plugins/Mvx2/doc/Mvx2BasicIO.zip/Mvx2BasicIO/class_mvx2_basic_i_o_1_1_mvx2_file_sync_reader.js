var class_mvx2_basic_i_o_1_1_mvx2_file_sync_reader =
[
    [ "Mvx2FileSyncReader", "class_mvx2_basic_i_o_1_1_mvx2_file_sync_reader.html#ad7d54c38b315117ffac2121e3b2a5e4f", null ],
    [ "~Mvx2FileSyncReader", "class_mvx2_basic_i_o_1_1_mvx2_file_sync_reader.html#a229580f7da73a0a5a01fa5313b8983c6", null ],
    [ "ReadNextFrame", "class_mvx2_basic_i_o_1_1_mvx2_file_sync_reader.html#ad618b1e2b693f61c5a0327f1accfdaa9", null ]
];