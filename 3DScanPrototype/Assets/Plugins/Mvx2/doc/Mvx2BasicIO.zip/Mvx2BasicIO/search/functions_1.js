var searchData=
[
  ['enablerecording_70',['EnableRecording',['../class_mvx2_basic_i_o_1_1_mvx2_file_async_writer_graph_node.html#a533b493f97d56613efb7e5021be1664f',1,'Mvx2BasicIO::Mvx2FileAsyncWriterGraphNode::EnableRecording()'],['../class_mvx2_basic_i_o_1_1_mvx2_file_writer_graph_node.html#afaecae6119a5dfc7c8675bce3d997eba',1,'Mvx2BasicIO::Mvx2FileWriterGraphNode::EnableRecording()']]],
  ['enabletransmission_71',['EnableTransmission',['../class_mvx2_basic_i_o_1_1_network_transmitter_graph_node.html#a2dc1ac25f8db0a995972dfaec1ad38da',1,'Mvx2BasicIO::NetworkTransmitterGraphNode']]]
];
