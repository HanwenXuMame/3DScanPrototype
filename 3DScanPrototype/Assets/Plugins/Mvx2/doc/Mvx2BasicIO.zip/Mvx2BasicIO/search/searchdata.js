var indexSectionsWithContent =
{
  0: "cefghimnprs~",
  1: "mn",
  2: "ceghimnprs~",
  3: "f",
  4: "f",
  5: "f",
  6: "mr"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "enums",
  5: "enumvalues",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Functions",
  3: "Variables",
  4: "Enumerations",
  5: "Enumerator",
  6: "Pages"
};

