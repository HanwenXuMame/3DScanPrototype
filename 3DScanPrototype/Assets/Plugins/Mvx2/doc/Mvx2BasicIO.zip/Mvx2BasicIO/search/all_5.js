var searchData=
[
  ['issingleframe_25',['IsSingleFrame',['../class_mvx2_basic_i_o_1_1_mvx2_file_basic_data_info.html#a93d81936c11a78339fc706ec6d196ea2',1,'Mvx2BasicIO::Mvx2FileBasicDataInfo']]],
  ['isvalid_26',['IsValid',['../class_mvx2_basic_i_o_1_1_mvx2_file_basic_data_info.html#a3a16e8969c9286a4ec53b84b8e014463',1,'Mvx2BasicIO::Mvx2FileBasicDataInfo']]]
];
