var searchData=
[
  ['apache_20v2_20license_0',['Apache v2 license',['../apache_v2_license.html',1,'draco_notes']]]
];
