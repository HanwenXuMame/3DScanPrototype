var indexSectionsWithContent =
{
  0: "mrst",
  1: "mrst"
};

var indexSectionNames =
{
  0: "all",
  1: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Pages"
};

